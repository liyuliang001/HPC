scp -r ./* s2010011297@166.111.131.80:~/hw1/codepackage
